﻿using Domain.Models;

namespace Domain.Interfaces
{
    public interface IInvoiceRepository : IRepository<Invoice>
    {
        //Task<Invoice> GetInvoiceAsync(int id);
        //Task<List<Invoice>> GetInvoicesAsync(int pageNumber, int pageSize);
        //Task<Invoice> CreateInvoiceAsync(Invoice invoice);
        //Task<Invoice> UpdateInvoiceAsync(Invoice invoice);
        //Task<bool> DeleteInvoiceAsync(int id);
    }
}
