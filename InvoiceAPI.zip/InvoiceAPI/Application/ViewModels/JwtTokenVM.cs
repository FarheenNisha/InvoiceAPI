﻿namespace Application.ViewModels
{
    public class JwtTokenVM
    {
        public string JwtToken { get; set; }
        public string RefreshToken { get; set; }
        public string Error { get; set; }
    }
}
